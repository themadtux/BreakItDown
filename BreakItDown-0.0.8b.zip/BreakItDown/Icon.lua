local ADDON, ns = ...

-- Round, draggable launcher button.
--   Left-click : disenchant the next item in the queue
--   Right-click: open/close the main window (slides out away from the screen edge)
--   Drag       : move it anywhere (out of combat)
-- The outer ring is orange normally and turns green when there is something
-- in your bags that can be disenchanted.

local Icon = {}
ns.Icon = Icon

local SIZE = 44
local ORANGE = { 0.85, 0.50, 0.20 }
local GREEN  = { 0.20, 0.90, 0.30 }
local INNER  = { 0.075, 0.065, 0.055 }
local INNER_HOVER = { 0.13, 0.115, 0.095 }
local CIRCLE_MASK = "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask"
local DISENCHANT_SPELL_ID = 13262

local function Circle(frame, tex)
    if frame.CreateMaskTexture then
        local m = frame:CreateMaskTexture()
        m:SetTexture(CIRCLE_MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
        m:SetAllPoints(tex)
        tex:AddMaskTexture(m)
    end
end

local function SpellIcon()
    local tex
    if C_Spell and C_Spell.GetSpellTexture then
        tex = C_Spell.GetSpellTexture(DISENCHANT_SPELL_ID)
    elseif GetSpellTexture then
        tex = GetSpellTexture(DISENCHANT_SPELL_ID)
    end
    return tex or "Interface\\Icons\\Spell_Holy_RemoveCurse"
end

function Icon:Build()
    if self.frame then return end

    local b = CreateFrame("Button", "BreakItDownIcon", UIParent, "SecureActionButtonTemplate")
    b:SetSize(SIZE, SIZE)
    b:SetFrameStrata("MEDIUM")
    b:SetClampedToScreen(true)
    b:SetMovable(true)
    b:EnableMouse(true)
    -- Up-clicks only, so pressing down to start a drag never fires a disenchant
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")
    b:SetAttribute("type1", "macro")   -- left-click = secure macro; right-click handled in PostClick
    -- Always act on mouse-up. Without this, a secure button can wait for a mouse-DOWN
    -- when "cast on key press" is enabled, and never fire because we only listen for Up.
    b:SetAttribute("useOnKeyDown", false)
    self.frame = b

    -- Ring (coloured), inner dark disc, spell icon
    local ring = b:CreateTexture(nil, "BACKGROUND")
    ring:SetAllPoints()
    ring:SetColorTexture(ORANGE[1], ORANGE[2], ORANGE[3], 1)
    Circle(b, ring)
    self.ring = ring

    local inner = b:CreateTexture(nil, "BORDER")
    inner:SetPoint("TOPLEFT", 3, -3)
    inner:SetPoint("BOTTOMRIGHT", -3, 3)
    inner:SetColorTexture(INNER[1], INNER[2], INNER[3], 1)
    Circle(b, inner)
    self.inner = inner

    local glyph = b:CreateTexture(nil, "ARTWORK")
    glyph:SetSize(24, 24)
    glyph:SetPoint("CENTER", 0, 0)
    glyph:SetTexture(SpellIcon())
    glyph:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    self.glyph = glyph

    -- Small queue count in the corner
    local overlay = CreateFrame("Frame", nil, b)
    overlay:SetAllPoints()
    overlay:SetFrameLevel(b:GetFrameLevel() + 3)
    local count = overlay:CreateFontString(nil, "OVERLAY")
    ns.Theme:Font(count, 11, "OUTLINE")
    count:SetPoint("BOTTOMRIGHT", 1, -1)
    self.count = count

    -- Dragging ------------------------------------------------------------
    b:SetScript("OnDragStart", function(s)
        if InCombatLockdown() then return end
        GameTooltip:Hide()
        s:StartMoving()
    end)
    b:SetScript("OnDragStop", function(s)
        s:StopMovingOrSizing()
        local point, _, relPoint, x, y = s:GetPoint()
        ns.db.iconPoint, ns.db.iconRelPoint, ns.db.iconX, ns.db.iconY = point, relPoint, x, y
        -- If the window is open, pick the side with room again
        local c = ns.Compact
        if c.frame and c.frame:IsShown() then
            c.slideDir = c:ComputeDir()
            c:Place(0)
        end
    end)

    -- Refresh the macro just before a left-click acts, so it always targets the current item
    b:SetScript("PreClick", function(_, button)
        if button == "LeftButton" then Icon:ApplySecure() end
    end)

    -- Right-click toggles the main window (left-click is the secure macro) --------
    b:SetScript("PostClick", function(_, button)
        if button == "RightButton" then ns.Compact:Toggle() end
    end)

    -- Hover + tooltip -----------------------------------------------------------
    b:SetScript("OnEnter", function(s)
        inner:SetColorTexture(INNER_HOVER[1], INNER_HOVER[2], INNER_HOVER[3], 1)
        GameTooltip:SetOwner(s, "ANCHOR_LEFT")
        GameTooltip:AddLine("BreakItDown")
        local item = ns.queue[1]
        if item then
            GameTooltip:AddLine("Next: " .. item.link, 1, 1, 1)
            GameTooltip:AddLine("In queue: " .. #ns.queue, 0.7, 0.7, 0.7)
        else
            GameTooltip:AddLine("Nothing to disenchant", 0.7, 0.7, 0.7)
        end
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Left-click: Disenchant", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Right-click: Open window", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Drag: Move", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function()
        inner:SetColorTexture(INNER[1], INNER[2], INNER[3], 1)
        GameTooltip:Hide()
    end)

    self:RestorePosition()
    if ns.db.iconShown == false then b:Hide() end
end

function Icon:RestorePosition()
    local b, db = self.frame, ns.db
    if not b then return end
    b:ClearAllPoints()
    b:SetPoint(db.iconPoint, UIParent, db.iconRelPoint, db.iconX, db.iconY)
end

function Icon:ToggleVisible()
    local b = self.frame
    if not b then return end
    if b:IsShown() then
        b:Hide(); ns.db.iconShown = false
    else
        b:Show(); ns.db.iconShown = true
    end
end

-- Visual state only (safe in combat)
function Icon:Update()
    local b = self.frame
    if not b then return end
    local n = #ns.queue
    local c = (n > 0) and GREEN or ORANGE
    self.ring:SetColorTexture(c[1], c[2], c[3], 1)
    self.glyph:SetDesaturated(n == 0)
    self.glyph:SetAlpha(n == 0 and 0.6 or 1)
    self.count:SetText(n > 0 and n or "")
    self.count:SetTextColor(GREEN[1], GREEN[2], GREEN[3])
end

-- The icon's left-click is a secure macro; it can only change out of combat.
function Icon:ApplySecure()
    local b = self.frame
    if not b or InCombatLockdown() then return end
    local item = ns.queue[1]
    if item then
        b:SetAttribute("macrotext1",
            "/cast " .. ns:GetSpellName() .. "\n/use " .. item.bag .. " " .. item.slot)
    else
        b:SetAttribute("macrotext1", "")
    end
end
