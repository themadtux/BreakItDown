local ADDON, ns = ...

-- Flat, dark, thin-border look that follows the EllesmereUI accent colour
-- when EllesmereUI is loaded, and falls back to its default green otherwise.

local Theme = {}
ns.Theme = Theme

local FALLBACK_ACCENT = { 0.047, 0.824, 0.624 }
local BG     = { 0.098, 0.086, 0.071, 1 }      -- #191612
local BTN_BG = { 0.125, 0.110, 0.094, 1 }      -- slightly lighter warm tone
local BORDER = { 0.20, 0.20, 0.20, 1 }         -- #333333
local TEXT   = { 0.85, 0.87, 0.90 }
local DIM    = { 0.50, 0.53, 0.58 }

Theme.BG, Theme.BORDER, Theme.TEXT, Theme.DIM = BG, BORDER, TEXT, DIM

local BACKDROP = {
    bgFile = "Interface\\Buttons\\WHITE8x8",
    edgeFile = "Interface\\Buttons\\WHITE8x8",
    edgeSize = 1,
}

-- ---------------------------------------------------------------------------
-- EllesmereUI probing (all guarded; the exact API is not known, so try a few
-- likely names and fall back quietly)
-- ---------------------------------------------------------------------------
local function Normalize(a, b, c)
    if type(a) == "table" then
        local r, g, bl = a.r or a[1], a.g or a[2], a.b or a[3]
        if type(r) == "number" and type(g) == "number" and type(bl) == "number" then
            return r, g, bl
        end
    elseif type(a) == "number" and type(b) == "number" and type(c) == "number" then
        return a, b, c
    end
end

local function Probe(E, names)
    for _, name in ipairs(names) do
        local v = E[name]
        if type(v) == "function" then
            local ok, a, b, c = pcall(v, E)
            if ok then
                local r, g, bl = Normalize(a, b, c)
                if r then return r, g, bl end
            end
            ok, a, b, c = pcall(v)
            if ok then
                local r, g, bl = Normalize(a, b, c)
                if r then return r, g, bl end
            end
        elseif type(v) == "table" then
            local r, g, bl = Normalize(v)
            if r then return r, g, bl end
        end
    end
end

function Theme:GetAccent()
    local E = _G.EllesmereUI
    if type(E) == "table" then
        local r, g, b = Probe(E, {
            "GetAccentColor", "GetAccent", "GetActiveAccent",
            "accent", "Accent", "ACCENT", "accentColor", "AccentColor",
        })
        if r then return r, g, b end
    end
    return FALLBACK_ACCENT[1], FALLBACK_ACCENT[2], FALLBACK_ACCENT[3]
end

function Theme:GetFontPath()
    local E = _G.EllesmereUI
    if type(E) == "table" then
        for _, name in ipairs({ "GetFontPath", "GetFont", "fontPath", "FONT", "font" }) do
            local v = E[name]
            if type(v) == "function" then
                local ok, res = pcall(v, E)
                if ok and type(res) == "string" and res:find("[\\/]") then return res end
            elseif type(v) == "string" and v:find("[\\/]") then
                return v
            end
        end
    end
    return STANDARD_TEXT_FONT
end

function Theme:Font(fs, size, flags)
    fs:SetFont(self:GetFontPath(), size or 12, flags or "")
end

-- ---------------------------------------------------------------------------
-- Accent registry: anything accent-coloured registers a callback here so the
-- whole UI re-tints in one call (/bid refresh, on show, etc).
-- ---------------------------------------------------------------------------
local registry = {}

function Theme:Register(fn)
    registry[#registry + 1] = fn
    fn(self:GetAccent())
end

function Theme:Refresh()
    local r, g, b = self:GetAccent()
    for _, fn in ipairs(registry) do fn(r, g, b) end
end

-- ---------------------------------------------------------------------------
-- Widgets
-- ---------------------------------------------------------------------------
function Theme:SkinFrame(f)
    f:SetBackdrop(BACKDROP)
    f:SetBackdropColor(unpack(BG))
    f:SetBackdropBorderColor(unpack(BORDER))
end

function Theme:CreateButton(parent, text, w, h, secure)
    local template = secure and "SecureActionButtonTemplate,BackdropTemplate" or "BackdropTemplate"
    local b = CreateFrame("Button", nil, parent, template)
    b:SetSize(w, h)
    b:SetBackdrop(BACKDROP)
    b:SetBackdropColor(unpack(BTN_BG))
    b:SetBackdropBorderColor(unpack(BORDER))

    local fs = b:CreateFontString(nil, "OVERLAY")
    self:Font(fs, 12)
    fs:SetPoint("CENTER", 0, 0)
    fs:SetText(text)
    fs:SetTextColor(unpack(TEXT))
    b.text = fs

    b:HookScript("OnEnter", function(s)
        local r, g, bl = Theme:GetAccent()
        s:SetBackdropBorderColor(r, g, bl, 1)
        s.text:SetTextColor(r, g, bl)
    end)
    b:HookScript("OnLeave", function(s)
        s:SetBackdropBorderColor(unpack(BORDER))
        s.text:SetTextColor(unpack(TEXT))
    end)
    return b
end

function Theme:CreateBox(parent)
    local f = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    f:SetBackdrop(BACKDROP)
    f:SetBackdropColor(0.047, 0.043, 0.035, 1)
    f:SetBackdropBorderColor(unpack(BORDER))
    return f
end
