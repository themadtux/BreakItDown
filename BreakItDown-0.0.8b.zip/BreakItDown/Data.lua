local ADDON, ns = ...

local Data = {}
ns.Data = Data

-- Each entry: { name = "fallback label", itemID = n }.
-- The window looks the real item name up from the itemID, so the full name
-- ("Greater Magic Essence", not "Essence") shows once the client has it cached.
-- "name" is only used until then, or if there is no itemID.
--
-- Per-item overrides, keyed by itemID (these win over the tables below):
--   Data.overrides[12345] = {
--       { name = "Greater Magic Essence", itemID = 10939 },
--       { name = "Strange Dust",          itemID = 10940 },
--   }
Data.overrides = {}

-- ---------------------------------------------------------------------------
-- Best-effort tables by item level, written from memory of the classic
-- disenchant chain. NOT verified against Forever, so treat them as a first
-- pass and correct them with Data.overrides (or edit here) as you find gaps.
-- ---------------------------------------------------------------------------

-- Uncommon: { max item level, dust, essence, shard }
local UNCOMMON = {
    { 15,  10940, 10938, nil   },
    { 25,  10940, 10939, 10978 },
    { 30,  11083, 10998, 11084 },
    { 35,  11083, 11082, 11084 },
    { 40,  11137, 11134, 11138 },
    { 45,  11137, 11135, 11139 },
    { 50,  11176, 11174, 11177 },
    { 55,  11176, 11175, 11178 },
    { 999, 16204, 16203, 14344 },
}

-- Rare (and lower epic) shards: { max item level, shard }
local SHARDS = {
    { 25,  10978 },
    { 35,  11084 },
    { 40,  11138 },
    { 45,  11139 },
    { 50,  11177 },
    { 55,  11178 },
    { 65,  14343 },
    { 999, 14344 },
}

local NEXUS_CRYSTAL = 20725

local function Band(tbl, ilvl)
    for _, b in ipairs(tbl) do
        if ilvl <= b[1] then return b end
    end
    return tbl[#tbl]
end

local function Entry(name, itemID)
    return { name = name, itemID = itemID }
end

-- Returns a list of { name, itemID } entries.
function Data:GetBreakdown(item)
    if not item then return {} end

    local raw = self.overrides[item.itemID]
    if raw then
        local out = {}
        for i, e in ipairs(raw) do
            if type(e) == "string" then e = { name = e } end
            out[i] = e
        end
        return out
    end

    local ilvl = item.ilvl or 0
    local out = {}

    if item.quality == 2 then
        local b = Band(UNCOMMON, ilvl)
        out[#out + 1] = Entry("Dust", b[2])
        out[#out + 1] = Entry("Essence", b[3])
        if b[4] then out[#out + 1] = Entry("Shard", b[4]) end

    elseif item.quality == 3 then
        out[#out + 1] = Entry("Shard", Band(SHARDS, ilvl)[2])
        if ilvl >= 56 then out[#out + 1] = Entry("Nexus Crystal", NEXUS_CRYSTAL) end

    elseif item.quality == 4 then
        if ilvl >= 56 then
            out[#out + 1] = Entry("Nexus Crystal", NEXUS_CRYSTAL)
        else
            out[#out + 1] = Entry("Shard", Band(SHARDS, ilvl)[2])
        end
    end

    return out
end
